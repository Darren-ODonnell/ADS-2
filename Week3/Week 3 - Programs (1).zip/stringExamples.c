#include <stdio.h>
#include <string.h>

int main()
{
    char delay;
    
    char name1[20], name2[20];
    
    printf("Enter the name: ");
    gets(name1);
    
    printf("There are %d chars in %s\n", strlen(name1), name1);
    
    //Assignment for strings
    strcpy(name2, name1);
    printf("Name 2 is %s \n", name2);
    
    //Compare strings for equality
    if (strcmp(name1, name2) == 0)
       printf("Both names are the same\n");
    else
        printf("Names are different\n");
    
    
   }
