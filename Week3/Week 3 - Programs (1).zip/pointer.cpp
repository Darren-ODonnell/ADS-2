#include <stdio.h>

int main()
{
    
    int num = 5;
    int *pointer = &num;
    
      printf("Num = %d\n", num);
    printf("Address = %u\n", pointer);

      printf("Num = %d\n", *pointer);    
     
}
